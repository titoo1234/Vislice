﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bum
{
    class bum
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Od kod naj štejem?");
            string od_kod = Console.ReadLine();
            int s1 = int.Parse(od_kod);
            Console.WriteLine("Do kod naj štejem?");
            string do_kod = Console.ReadLine();
            int s2 = int.Parse(do_kod);
            while (s1 <= s2)
            {

                if ((s1 % 3 == 0) || $"{s1}".Contains('3'))
                    {
                    Console.Write("Bum! ");
                }
                else
                {
                    Console.Write(s1 + " ");
                }
             
                s1++;
            }


        }
        }
    }

