﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Obrni_stevilo
{
    class obrni
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vnesi število");
            string st = Console.ReadLine();
            int stevilo = int.Parse(st);
            int stotice = stevilo / 100;
            int desetice = (stevilo / 10) % 10;
            int enice = stevilo % 10;
            int novo = enice * 100 + desetice * 10 + stotice;
            Console.WriteLine(novo);
            



        }
    }
}
