﻿using System;

namespace Pozri_nicle
{
    class pozri_nicle
    {
        static void Main(string[] args)
        {
            string st = Console.ReadLine();
            string niz = ""; 
            foreach (char c in st)
            {
                if (c != '0')
                {
                    niz += c;
                }
            }
            Console.WriteLine(niz);
        }
    }
}
