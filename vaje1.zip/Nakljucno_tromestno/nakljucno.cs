﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nakljucno_tromestno
{
    class nakljucno
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            int nakljucno = r.Next(100, 1000);


            Console.WriteLine(nakljucno);
        }
    }
}