﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Karo
{
    class karo
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vnesi število");
            string stevilo = Console.ReadLine();
            char prvo = stevilo[0];
            char drugo = stevilo[1];
            char tretje = stevilo[2];
            Console.WriteLine("  " + prvo);
            Console.WriteLine(" " + prvo + " " + drugo);
            Console.WriteLine( prvo + " " + drugo+ " " + tretje);
            Console.WriteLine(" " + prvo + " " + drugo);
            Console.WriteLine("  " + prvo);

        }
    }

}
     
